1. Unpack the zip file.
2. Copy the "laravel" folder to the "xampp\htdocs" folder.
3. By default, the welcome page is accessible at:

   http://localhost/laravel/public/

4. Rename the project folder if necessary.